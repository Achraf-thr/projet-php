<footer>
    <p>&copy; <?php echo date("Y"); ?> Site Éducatif pour Enfants. Tous droits réservés.</p>
</footer>
</body>
</html>
