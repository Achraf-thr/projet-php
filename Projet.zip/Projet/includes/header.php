<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?php echo $title; ?></title>
    <link rel="stylesheet" href="/style.css">
</head>
<body>
    <header>
        <h1>Site Éducatif pour Enfants</h1>
        <nav>
            <ul>
                <li><a href="/index.php">Accueil</a></li>
                <li><a href="/categorie.php">Catégories</a></li>
                <li><a href="/admin/login.php">Admin</a></li>
            </ul>
        </nav>
    </header>
